using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Hold : MonoBehaviour
{
    public bool hold;
    public float distance = 2f;
    RaycastHit2D Hit;
    public Transform holdPoint;

    public float throwGameObject = 5;
    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        if (Input.GetKeyDown(KeyCode.F)){
            if(!hold) {
                Physics2D.queriesStartInColliders = false;
                Hit = Physics2D.Raycast(transform.position,Vector2.right * transform.localScale.x, distance);
                if (Hit.collider != null && Hit.collider.tag == "UdonShoot"){
                    hold = true;
                }
            }
            else{
                hold = false;
                if (Hit.collider.gameObject.GetComponent<Rigidbody2D>() != null){
                    Hit.collider.gameObject.GetComponent<Rigidbody2D>().velocity = new Vector2(transform.localScale.x,1) * throwGameObject;
                }
            }
        }  
    if(hold){
        Hit.collider.gameObject.transform.position =  holdPoint.position;

        if (holdPoint.position.x > transform.position.x && hold==true){
            Hit.collider.gameObject.transform.localScale = new Vector2(transform.localScale.x*0.2f,transform.localScale.y*0.2f);
        }
        else if(holdPoint.position.x < transform.position.x && hold==true){
            Hit.collider.gameObject.transform.localScale = new Vector2(transform.localScale.x*0.2f,transform.localScale.y*0.2f);
        }
        }
    }      

    private void OnDrawGizmos(){
    Gizmos.color = Color.red;
    Gizmos.DrawLine(transform.position,transform.position + Vector3.right * transform.localScale.x * distance);
    }
}