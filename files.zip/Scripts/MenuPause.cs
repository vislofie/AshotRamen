using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class MenuPause : MonoBehaviour
{
     public GameObject MenuandPause;
     public GameObject twoSettingsMenu;
     void Update(){
     	if (Input.GetKeyDown(KeyCode.Escape)){
		MenuandPause.SetActive(true);
     	}
     }
     public void BackPauseMenu(){
	MenuandPause.SetActive(false);
     }
     public void SettingsMenu(){
      	MenuandPause.SetActive(false);
     	twoSettingsMenu.SetActive(true);
     }
     public void Menu(){
     	SceneManager.LoadScene(0);
     }
}
