using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class MenuBack : MonoBehaviour
{
    public GameObject Menu;
    public GameObject MenuSettings;
    public void play()
    {
        SceneManager.LoadScene(1);
    }
    public void settings()
    {
        Menu.SetActive(false);
        MenuSettings.SetActive(true);
    }
    public void exit()
    {
        Application.Quit();
    }
}
