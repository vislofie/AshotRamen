using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ScriptMain : MonoBehaviour
{
    public Rigidbody2D rb;
    public Animator anim;
    public SpriteRenderer sr;
    public string Key;
    public Vector2 moveVector;
    public float buttonTime = 0.3f;
    public float jumpAmount = 5;
    public float Score;  
    public Transform groundCheck;
    public LayerMask groundMask;
    private float Radius = 0.3f;
    private int SpeedWalk = 3;
    private int SpeedRun = 6;
    float jumpTime;
    bool jumping;
    private bool isGrounded;
    void Start()
    {
        rb = GetComponent<Rigidbody2D>();
        anim = GetComponent<Animator>();
        sr = GetComponent<SpriteRenderer>();
    }

    // Update is called once per frame
    void Update()
    {
        Walk(); 
        Run();
        Jump();
    }
    void Walk(){
        moveVector.x = Input.GetAxis("Horizontal");
        anim.SetFloat("moveX",Mathf.Abs(moveVector.x));
        Score = 0.1f;
        anim.SetFloat("Score",Score);
        transform.position += new Vector3(moveVector.x,0,0) * SpeedWalk * Time.deltaTime;
        if (moveVector.x > 0){
            sr.flipX = false;
        }else if(moveVector.x < 0){
            sr.flipX = true;
        }
    }
    void Run(){
        if (Input.GetKey(KeyCode.LeftShift))
        {
        Score = 1.1f;
        moveVector.x = Input.GetAxis("Horizontal");
        anim.SetFloat("Score",Score);
        transform.position += new Vector3(moveVector.x,0,0) * SpeedRun * Time.deltaTime;
        if (moveVector.x > 0){
            sr.flipX = false;
        }else if(moveVector.x < 0){
            sr.flipX = true;
        }
        }
    }
    void Jump(){
        isGrounded = Physics2D.OverlapCircle(groundCheck.position,Radius,groundMask);
        if (Input.GetKeyDown(KeyCode.Space) && isGrounded)  
        {
        jumping = true;
        jumpTime = 0;
        }
        if(jumping)
        {
            rb.velocity = new Vector2(rb.velocity.x, jumpAmount);
            jumpTime += Time.deltaTime;
        }
        if(Input.GetKeyUp(KeyCode.Space) | jumpTime > buttonTime)
        {
            jumping = false;        
        }
        anim.SetFloat("moveY",Mathf.Abs(rb.velocity.y));
    }
    void Hurt(){
        /*Теряется хп и уменьшается полоска здоровья*/
    }
    void Shoot(){
        /*Cтреляет лапшой и ранит соперника*/
    }
}
